import { getOrCreateUser } from "../services/userService.js";
import { languageKeyboard } from "../keyboards/language.js";
import { LANGUAGES } from "../config/constants.js";
import { t } from "../utils/i18n.js";

export async function languageCommand(ctx) {
  await ctx.reply(t("uz", "choose_language"), { reply_markup: languageKeyboard() });
}

export async function languageCallback(ctx) {
  const lang = ctx.callbackQuery.data.replace("lang_", "");

  if (!LANGUAGES.includes(lang)) {
    await ctx.answerCallbackQuery();
    return;
  }

  const user = await getOrCreateUser(ctx);
  user.language = lang;
  await user.save();

  await ctx.answerCallbackQuery();
  await ctx.editMessageText(t(lang, "language_changed"));
}
